export const arrowTopSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
