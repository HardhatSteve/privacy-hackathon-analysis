export const compassSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
