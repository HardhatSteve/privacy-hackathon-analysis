export const moreSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
