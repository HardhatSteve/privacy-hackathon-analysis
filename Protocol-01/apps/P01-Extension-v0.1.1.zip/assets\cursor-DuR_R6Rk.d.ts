export const cursorSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
