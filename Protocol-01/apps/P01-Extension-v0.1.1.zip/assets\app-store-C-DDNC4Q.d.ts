export const appStoreSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
