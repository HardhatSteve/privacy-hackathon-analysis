export const addSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
