export const recycleHorizontalSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
