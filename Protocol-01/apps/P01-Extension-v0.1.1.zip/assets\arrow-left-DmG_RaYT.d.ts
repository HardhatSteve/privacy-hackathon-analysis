export const arrowLeftSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
