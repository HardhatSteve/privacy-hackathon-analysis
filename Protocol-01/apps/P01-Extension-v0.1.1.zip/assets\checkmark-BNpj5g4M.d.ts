export const checkmarkSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
