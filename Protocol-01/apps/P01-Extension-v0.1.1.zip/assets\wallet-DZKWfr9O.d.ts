export const walletSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
