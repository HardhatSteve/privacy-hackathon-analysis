export const offSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
