export const chevronTopSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
