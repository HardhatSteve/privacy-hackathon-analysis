export const verifySvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
