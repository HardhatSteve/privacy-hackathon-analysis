export const swapHorizontalRoundedBoldSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
