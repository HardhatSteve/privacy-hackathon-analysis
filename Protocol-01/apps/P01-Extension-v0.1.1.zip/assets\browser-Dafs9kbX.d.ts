export const browserSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
