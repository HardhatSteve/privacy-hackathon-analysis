export const plusSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
