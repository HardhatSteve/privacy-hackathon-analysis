export const searchSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
