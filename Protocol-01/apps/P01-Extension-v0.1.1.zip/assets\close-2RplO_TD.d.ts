export const closeSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
