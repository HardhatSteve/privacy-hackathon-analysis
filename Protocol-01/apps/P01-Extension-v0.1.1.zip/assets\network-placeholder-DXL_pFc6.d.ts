export const networkPlaceholderSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
