declare namespace UiHelperUtil {
    function getSpacingStyles(spacing: any, index: any): string;
    function getFormattedDate(date: any): string;
    function getHostName(url: any): string;
    function getTruncateString({ string, charsStart, charsEnd, truncate }: {
        string: any;
        charsStart: any;
        charsEnd: any;
        truncate: any;
    }): any;
    function generateAvatarColors(address: any): string;
    function hexToRgb(hex: any): number[];
    function tintColor(rgb: any, tint: any): number[];
    function isNumber(character: any): boolean;
    function getColorTheme(theme: any): any;
    function splitBalance(input: any): any[];
    function roundNumber(number: any, threshold: any, fixed: any): any;
    function formatNumberToLocalString(value: any, decimals?: number): string;
}
declare function e(...e2: any[]): {
    _$litDirective$: any;
    values: any[];
};
declare function customElement(tagName: any): (classOrDescriptor: any) => any;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
declare function e$1(t2: any): (...e2: any[]) => {
    _$litDirective$: any;
    values: any[];
};
declare const f_base: {
    new (t2: any): {
        get _$AU(): any;
        _$AT(t2: any, e2: any, i3: any): void;
        _$Ct: any;
        _$AM: any;
        _$Ci: any;
        _$AS(t2: any, e2: any): any;
        update(t2: any, e2: any): any;
    };
};
export class f extends f_base {
    constructor(...args: any[]);
    isConnected: any;
    _$AO(i3: any, t2?: boolean): void;
    setValue(t2: any): void;
    disconnected(): void;
    reconnected(): void;
}
declare function n$3(t2: any): (e2: any, o2: any) => PropertyDescriptor | ((r3: any) => void) | {
    set(r3: any): void;
    init(e3: any): any;
};
/**
 * @license
 * Copyright 2018 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
declare function o$1(o2: any): any;
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */
declare function r$2(r2: any): (e2: any, o2: any) => PropertyDescriptor | ((r3: any) => void) | {
    set(r3: any): void;
    init(e3: any): any;
};
export { UiHelperUtil as U, e as a, customElement as c, e$1 as e, n$3 as n, o$1 as o, r$2 as r };
