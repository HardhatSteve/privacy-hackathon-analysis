export function ccipRequest({ data, sender, urls }: {
    data: any;
    sender: any;
    urls: any;
}): Promise<any>;
export function offchainLookup(client: any, { blockNumber, blockTag, data, to }: {
    blockNumber: any;
    blockTag: any;
    data: any;
    to: any;
}): Promise<any>;
export namespace offchainLookupAbiItem {
    let name: string;
    let type: string;
    let inputs: {
        name: string;
        type: string;
    }[];
}
export const offchainLookupSignature: "0x556f1830";
