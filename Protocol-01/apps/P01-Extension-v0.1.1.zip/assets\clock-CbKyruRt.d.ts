export const clockSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
