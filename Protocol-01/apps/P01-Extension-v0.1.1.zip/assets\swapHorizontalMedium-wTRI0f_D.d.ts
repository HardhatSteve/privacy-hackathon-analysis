export const swapHorizontalMediumSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
