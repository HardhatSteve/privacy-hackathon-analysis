import { w } from "./core-Cr9DYdFt.js";
import "./popup.html-Dy5lSDZO.js";
import "./storage-B2ZD4aVa.js";
const cursorSvg = w` <svg fill="none" viewBox="0 0 13 4">
  <path fill="currentColor" d="M.5 0h12L8.9 3.13a3.76 3.76 0 0 1-4.8 0L.5 0Z" />
</svg>`;
export {
  cursorSvg
};
