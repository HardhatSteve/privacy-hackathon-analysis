export const refreshSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
