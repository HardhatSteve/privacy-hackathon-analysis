import { w } from "./core-Cr9DYdFt.js";
import "./popup.html-Dy5lSDZO.js";
import "./storage-B2ZD4aVa.js";
const chevronTopSvg = w`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M14.54 11.04a1 1 0 0 1-1.41 0L8 5.92l-5.13 5.12a1 1 0 1 1-1.41-1.41l5.83-5.84a1 1 0 0 1 1.42 0l5.83 5.84a1 1 0 0 1 0 1.41Z"
    clip-rule="evenodd"
  />
</svg>`;
export {
  chevronTopSvg
};
