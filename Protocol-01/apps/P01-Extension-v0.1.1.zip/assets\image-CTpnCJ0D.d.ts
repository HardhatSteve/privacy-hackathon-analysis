export const imageSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
