export const etherscanSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
