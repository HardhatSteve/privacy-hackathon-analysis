declare const React$2: any;
declare function createJSONStorage(getStorage: any, options: any): {
    getItem: (name: any) => any;
    setItem: (name: any, newValue: any) => any;
    removeItem: (name: any) => any;
};
declare namespace chromeStorage {
    function getItem(name: any): Promise<any>;
    function setItem(name: any, value: any): Promise<void>;
    function removeItem(name: any): Promise<void>;
}
declare function create(createState: any): (createState: any) => (selector: any, equalityFn: any) => any;
declare var reactExports: {};
declare var commonjsGlobal: {};
declare function getAugmentedNamespace(n2: any): any;
declare function getDefaultExportFromCjs(x2: any): any;
declare function approveRequest(requestId: any, data: any): Promise<any>;
declare function initBackgroundMessageListener(): void;
declare function rejectRequest(requestId: any, reason: any): Promise<any>;
declare function persist(config: any, baseOptions: any): (set: any, get: any, api: any) => any;
declare function registerHandler(type: any, handler: any): void;
declare function sendToBackground(type: any, payload: any): Promise<any>;
export const t: any;
export { React$2 as R, createJSONStorage as a, chromeStorage as b, create as c, reactExports as d, commonjsGlobal as e, getAugmentedNamespace as f, getDefaultExportFromCjs as g, approveRequest as h, initBackgroundMessageListener as i, rejectRequest as j, persist as p, registerHandler as r, sendToBackground as s };
