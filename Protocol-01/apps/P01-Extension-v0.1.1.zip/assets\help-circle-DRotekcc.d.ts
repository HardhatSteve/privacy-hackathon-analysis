export const helpCircleSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
