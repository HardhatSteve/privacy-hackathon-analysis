export const chromeStoreSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
