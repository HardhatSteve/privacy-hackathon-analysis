export const disconnectSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
