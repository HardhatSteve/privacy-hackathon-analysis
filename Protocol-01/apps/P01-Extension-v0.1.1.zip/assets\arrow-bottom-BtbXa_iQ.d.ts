export const arrowBottomSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
