export const qrCodeIcon: {
    _$litType$: any;
    strings: any;
    values: any[];
};
