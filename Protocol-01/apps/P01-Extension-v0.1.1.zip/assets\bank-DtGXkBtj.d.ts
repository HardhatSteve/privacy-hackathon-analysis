export const bankSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
