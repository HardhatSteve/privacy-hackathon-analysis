export const desktopSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
