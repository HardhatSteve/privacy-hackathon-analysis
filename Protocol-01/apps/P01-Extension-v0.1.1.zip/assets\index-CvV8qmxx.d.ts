export const WebAuthnAbortService: BaseWebAuthnAbortService;
export class WebAuthnError extends Error {
    constructor({ message, code, cause, name }: {
        message: any;
        code: any;
        cause: any;
        name: any;
    });
    name: any;
    code: any;
}
export function base64URLStringToBuffer(base64URLString: any): ArrayBuffer;
export function browserSupportsWebAuthn(): boolean;
export function browserSupportsWebAuthnAutofill(): Promise<any>;
export function bufferToBase64URLString(buffer: any): string;
export function platformAuthenticatorIsAvailable(): Promise<any>;
export function startAuthentication(requestOptionsJSON: any, useBrowserAutofill?: boolean): Promise<{
    id: string;
    rawId: string;
    response: {
        authenticatorData: string;
        clientDataJSON: string;
        signature: string;
        userHandle: any;
    };
    type: string;
    clientExtensionResults: any;
    authenticatorAttachment: any;
}>;
export function startRegistration(creationOptionsJSON: any): Promise<{
    id: string;
    rawId: string;
    response: {
        attestationObject: string;
        clientDataJSON: string;
        transports: any;
        publicKeyAlgorithm: any;
        publicKey: any;
        authenticatorData: string;
    };
    type: string;
    clientExtensionResults: any;
    authenticatorAttachment: any;
}>;
declare class BaseWebAuthnAbortService {
    createNewAbortSignal(): AbortSignal;
    controller: AbortController;
    cancelCeremony(): void;
}
export {};
