declare function Field$1(ORDER: any, bitLenOrOpts: any, isLE2?: boolean, opts?: {}): Readonly<Readonly<{
    ORDER: any;
    isLE: boolean;
    BITS: any;
    BYTES: number;
    MASK: bigint;
    ZERO: bigint;
    ONE: bigint;
    allowedLengths: any;
    create: (num: any) => any;
    isValid: (num: any) => boolean;
    is0: (num: any) => boolean;
    isValidNot0: (num: any) => boolean;
    isOdd: (num: any) => boolean;
    neg: (num: any) => any;
    eql: (lhs: any, rhs: any) => boolean;
    sqr: (num: any) => any;
    add: (lhs: any, rhs: any) => any;
    sub: (lhs: any, rhs: any) => any;
    mul: (lhs: any, rhs: any) => any;
    pow: (num: any, power: any) => any;
    div: (lhs: any, rhs: any) => any;
    sqrN: (num: any) => number;
    addN: (lhs: any, rhs: any) => any;
    subN: (lhs: any, rhs: any) => number;
    mulN: (lhs: any, rhs: any) => number;
    inv: (num: any) => any;
    sqrt: any;
    toBytes: (num: any) => any;
    fromBytes: (bytes: any, skipValidation?: boolean) => bigint;
    invertBatch: (lst: any) => any[];
    cmov: (a7: any, b2: any, c4: any) => any;
}>>;
declare const AbiEncodingLengthMismatchError_base: {
    new (shortMessage: any, args?: {}): {
        details: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
        version: string;
        walk(fn6: any): any;
        message: string;
        stack?: string;
        cause?: unknown;
    };
    isError(error: unknown): error is Error;
    captureStackTrace(targetObject: object, constructorOpt?: Function): void;
    prepareStackTrace(err: Error, stackTraces: NodeJS.CallSite[]): any;
    stackTraceLimit: number;
};
declare class AbiEncodingLengthMismatchError extends AbiEncodingLengthMismatchError_base {
    constructor({ expectedLength, givenLength }: {
        expectedLength: any;
        givenLength: any;
    });
}
declare let BytesSizeMismatchError$1: {
    new ({ expectedSize, givenSize }: {
        expectedSize: any;
        givenSize: any;
    }): {
        details: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
        version: string;
        walk(fn6: any): any;
        message: string;
        stack?: string;
        cause?: unknown;
    };
    isError(error: unknown): error is Error;
    captureStackTrace(targetObject: object, constructorOpt?: Function): void;
    prepareStackTrace(err: Error, stackTraces: NodeJS.CallSite[]): any;
    stackTraceLimit: number;
};
declare const ContractFunctionZeroDataError_base: {
    new (shortMessage: any, args?: {}): {
        details: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
        version: string;
        walk(fn6: any): any;
        message: string;
        stack?: string;
        cause?: unknown;
    };
    isError(error: unknown): error is Error;
    captureStackTrace(targetObject: object, constructorOpt?: Function): void;
    prepareStackTrace(err: Error, stackTraces: NodeJS.CallSite[]): any;
    stackTraceLimit: number;
};
declare class ContractFunctionZeroDataError extends ContractFunctionZeroDataError_base {
    constructor({ functionName }: {
        functionName: any;
    });
}
declare const ContractFunctionExecutionError_base: {
    new (shortMessage: any, args?: {}): {
        details: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
        version: string;
        walk(fn6: any): any;
        message: string;
        stack?: string;
        cause?: unknown;
    };
    isError(error: unknown): error is Error;
    captureStackTrace(targetObject: object, constructorOpt?: Function): void;
    prepareStackTrace(err: Error, stackTraces: NodeJS.CallSite[]): any;
    stackTraceLimit: number;
};
declare class ContractFunctionExecutionError extends ContractFunctionExecutionError_base {
    constructor(cause: any, { abi: abi2, args, contractAddress, docsPath: docsPath2, functionName, sender }: {
        abi: any;
        args: any;
        contractAddress: any;
        docsPath: any;
        functionName: any;
        sender: any;
    });
    abi: any;
    args: any;
    cause: any;
    contractAddress: any;
    functionName: any;
    sender: any;
}
declare const EventEmitter$1: any;
declare function hexToBigInt$1(hex2: any, opts?: {}): bigint;
declare const AccountNotFoundError_base: {
    new (shortMessage: any, args?: {}): {
        details: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
        version: string;
        walk(fn6: any): any;
        message: string;
        stack?: string;
        cause?: unknown;
    };
    isError(error: unknown): error is Error;
    captureStackTrace(targetObject: object, constructorOpt?: Function): void;
    prepareStackTrace(err: Error, stackTraces: NodeJS.CallSite[]): any;
    stackTraceLimit: number;
};
declare class AccountNotFoundError extends AccountNotFoundError_base {
    constructor({ docsPath: docsPath2 }?: {});
}
declare function encodeFunctionData(parameters: any): string;
declare let InvalidAddressError$1: {
    new ({ address }: {
        address: any;
    }): {
        details: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
        version: string;
        walk(fn6: any): any;
        message: string;
        stack?: string;
        cause?: unknown;
    };
    isError(error: unknown): error is Error;
    captureStackTrace(targetObject: object, constructorOpt?: Function): void;
    prepareStackTrace(err: Error, stackTraces: NodeJS.CallSite[]): any;
    stackTraceLimit: number;
};
declare function estimateFeesPerGas(client2: any, args: any): Promise<any>;
declare function prepareAuthorization(client2: any, parameters: any): Promise<{
    address: any;
    chainId: any;
    nonce: any;
}>;
declare let LruMap$2: {
    new (size2: any): {
        maxSize: any;
        get(key2: any): any;
        set(key2: any, value: any): /*elided*/ any;
        clear(): void;
        delete(key: any): boolean;
        forEach(callbackfn: (value: any, key: any, map: Map<any, any>) => void, thisArg?: any): void;
        has(key: any): boolean;
        readonly size: number;
        entries(): MapIterator<[any, any]>;
        keys(): MapIterator<any>;
        values(): MapIterator<any>;
        [Symbol.iterator](): MapIterator<[any, any]>;
        readonly [Symbol.toStringTag]: string;
    };
    groupBy<K, T>(items: Iterable<T>, keySelector: (item: T, index: number) => K): Map<K, T[]>;
    readonly [Symbol.species]: MapConstructor;
};
declare function parseAccount(account: any): any;
declare function getChainId(client2: any): Promise<number>;
declare function serializeStateOverride(parameters: any): {};
declare function formatLog(log2: any, { args, eventName }?: {}): any;
declare function formatTransactionReceipt(transactionReceipt: any, _18: any): any;
declare function stringify$3(value: any, replacer: any, space: any): string;
declare function observe(observerId: any, callbacks: any, fn6: any): () => void;
declare function poll(fn6: any, { emitOnBegin, initialWaitTime, interval }: {
    emitOnBegin: any;
    initialWaitTime: any;
    interval: any;
}): () => boolean;
declare const UnsupportedPackedAbiType_base: {
    new (shortMessage: any, args?: {}): {
        details: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
        version: string;
        walk(fn6: any): any;
        message: string;
        stack?: string;
        cause?: unknown;
    };
    isError(error: unknown): error is Error;
    captureStackTrace(targetObject: object, constructorOpt?: Function): void;
    prepareStackTrace(err: Error, stackTraces: NodeJS.CallSite[]): any;
    stackTraceLimit: number;
};
declare class UnsupportedPackedAbiType extends UnsupportedPackedAbiType_base {
    constructor(type2: any);
}
declare function createClient(parameters: any): {
    experimental_blockTag?: any;
    account: any;
    batch: any;
    cacheTime: any;
    ccipRead: any;
    chain: any;
    dataSuffix: any;
    key: any;
    name: any;
    pollingInterval: any;
    request: any;
    transport: any;
    type: any;
    uid: any;
} & {
    extend: (extendFn: any) => any;
};
declare function createPublicClient(parameters: any): any;
declare function http(url: any, config?: {}): ({ chain: chain2, retryCount: retryCount_, timeout: timeout_ }: {
    chain: any;
    retryCount: any;
    timeout: any;
}) => {
    config: {
        key: any;
        methods: any;
        name: any;
        request: any;
        retryCount: number;
        retryDelay: number;
        timeout: any;
        type: any;
    };
    request: (args: any, overrideOptions?: {}) => Promise<any>;
    value: any;
};
declare function isHex$1(value: any, { strict }?: {
    strict?: boolean;
}): boolean;
declare function sha256$5(msg: any): any;
declare namespace sha256$5 {
    let outputLen: any;
    let blockLen: any;
    function create(): any;
}
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
declare function createCurve$1(curveDef: any, defHash: any): any;
declare const integerRegex$1: RegExp;
declare const localBatchGatewayUrl: "x-batch-gateway:true";
declare function sha256$5(msg: any): any;
declare namespace sha256$5 { }
declare function sha256$5(msg: any): any;
declare namespace sha256$5 { }
declare function sha256$5(msg: any): any;
declare namespace sha256$5 { }
declare function hashMessage(message: any, to_: any): any;
declare function slice$3(value: any, start: any, end: any, { strict }?: {}): any;
declare function toHex$3(value: any, opts?: {}): any;
declare function waitForCallsStatus(client2: any, parameters: any): Promise<any>;
declare function stringToBytes$1(value: any, opts?: {}): any;
declare function trim$2(hexOrBytes: any, { dir }?: {
    dir?: string;
}): any;
declare function decodeFunctionData(parameters: any): {
    functionName: any;
    args: any[];
};
declare function k$2(r8: any): any;
declare function A$3(r8: any): {
    logger: any;
    chunkLoggerController: {
        baseChunkLogger: {
            level: any;
            levelValue: any;
            MAX_LOG_SIZE_IN_BYTES: number;
            logs: {
                head: any;
                tail: {
                    nodeValue: any;
                    sizeInBytes: number;
                    next: any;
                    get value(): any;
                    get size(): number;
                };
                lengthInNodes: number;
                maxSizeInBytes: any;
                sizeInBytes: number;
                append(e8: any): void;
                shift(): void;
                toArray(): any[];
                get length(): number;
                get size(): number;
                toOrderedArray(): any[];
                [Symbol.iterator](): {
                    next: () => {
                        done: boolean;
                        value: any;
                    };
                };
            };
            forwardToConsole(e8: any, t8: any): void;
            appendToLogs(e8: any): void;
            getLogs(): {
                head: any;
                tail: {
                    nodeValue: any;
                    sizeInBytes: number;
                    next: any;
                    get value(): any;
                    get size(): number;
                };
                lengthInNodes: number;
                maxSizeInBytes: any;
                sizeInBytes: number;
                append(e8: any): void;
                shift(): void;
                toArray(): any[];
                get length(): number;
                get size(): number;
                toOrderedArray(): any[];
                [Symbol.iterator](): {
                    next: () => {
                        done: boolean;
                        value: any;
                    };
                };
            };
            clearLogs(): void;
            getLogArray(): any[];
            logsToBlob(e8: any): Blob;
        };
        write(e8: any): void;
        getLogs(): {
            head: any;
            tail: {
                nodeValue: any;
                sizeInBytes: number;
                next: any;
                get value(): any;
                get size(): number;
            };
            lengthInNodes: number;
            maxSizeInBytes: any;
            sizeInBytes: number;
            append(e8: any): void;
            shift(): void;
            toArray(): any[];
            get length(): number;
            get size(): number;
            toOrderedArray(): any[];
            [Symbol.iterator](): {
                next: () => {
                    done: boolean;
                    value: any;
                };
            };
        };
        clearLogs(): void;
        getLogArray(): any[];
        logsToBlob(e8: any): Blob;
    };
};
declare function E$3(r8: any, e8: any, t8?: string): any;
declare let i$2: {
    new (e8: any): {
        events: any;
        interval: any;
        init(): Promise<void>;
        stop(): void;
        on(e8: any, t8: any): void;
        once(e8: any, t8: any): void;
        off(e8: any, t8: any): void;
        removeListener(e8: any, t8: any): void;
        initialize(): Promise<void>;
        intervalRef: number;
        pulse(): void;
    };
    init(e8: any): Promise<{
        events: any;
        interval: any;
        init(): Promise<void>;
        stop(): void;
        on(e8: any, t8: any): void;
        once(e8: any, t8: any): void;
        off(e8: any, t8: any): void;
        removeListener(e8: any, t8: any): void;
        initialize(): Promise<void>;
        intervalRef: number;
        pulse(): void;
    }>;
};
declare let h$3: {
    new (): {
        initialized: boolean;
        setInitialized: (e8: any) => void;
        storage: {
            localStorage: {};
            getKeys(): Promise<string[]>;
            getEntries(): Promise<any[][]>;
            getItem(t8: any): Promise<any>;
            setItem(t8: any, e8: any): Promise<void>;
            removeItem(t8: any): Promise<void>;
        };
        getKeys(): Promise<string[]>;
        getEntries(): Promise<any[][]>;
        getItem(t8: any): Promise<any>;
        setItem(t8: any, e8: any): Promise<void>;
        removeItem(t8: any): Promise<void>;
        initialize(): Promise<void>;
    };
};
declare function y$2(r8: any, e8?: string): string;
declare function formatJsonRpcRequest(method: any, params: any, id2: any): {
    id: any;
    jsonrpc: string;
    method: any;
    params: any;
};
declare namespace r$1 {
    let pulse: string;
}
declare const Ot$2: any;
declare let o$1: {
    new (t8: any): {
        events: any;
        hasRegisteredEventListeners: boolean;
        connection: any;
        connect(t8?: any): Promise<void>;
        disconnect(): Promise<void>;
        on(t8: any, e8: any): void;
        once(t8: any, e8: any): void;
        off(t8: any, e8: any): void;
        removeListener(t8: any, e8: any): void;
        request(t8: any, e8: any): Promise<any>;
        requestStrict(t8: any, e8: any): Promise<any>;
        setConnection(t8?: any): any;
        onPayload(t8: any): void;
        onClose(t8: any): void;
        open(t8?: any): Promise<void>;
        close(): Promise<void>;
        registerEventListeners(): void;
    };
};
declare let f$5: {
    new (e8: any): {
        url: any;
        events: any;
        registering: boolean;
        get connected(): boolean;
        get connecting(): boolean;
        on(e8: any, t8: any): void;
        once(e8: any, t8: any): void;
        off(e8: any, t8: any): void;
        removeListener(e8: any, t8: any): void;
        open(e8?: any): Promise<void>;
        close(): Promise<any>;
        send(e8: any): Promise<void>;
        socket: any;
        register(e8?: any): Promise<any>;
        onOpen(e8: any): void;
        onClose(e8: any): void;
        onPayload(e8: any): void;
        onError(e8: any, t8: any): void;
        parseError(e8: any, t8?: any): any;
        resetMaxListeners(): void;
        emitError(e8: any): any;
    };
};
declare function isJsonRpcRequest(payload: any): boolean;
declare function isJsonRpcResponse(payload: any): boolean;
declare function formatJsonRpcResult(id2: any, result2: any): {
    id: any;
    jsonrpc: string;
    result: any;
};
declare const Nt$4: any;
declare function Po$3(t8?: any): {
    secretKey: any;
    publicKey: any;
};
declare function Qe$3(t8: any): string;
declare function Qo$3(t8: any, e8: any, n6: any, r8: any, o9?: any): Promise<string>;
declare function safeJsonStringify(value: any): string;
declare function safeJsonParse(value: any): any;
declare function getBigIntRpcId(entropy?: number): bigint;
declare function formatJsonRpcError(id2: any, error: any, data: any): {
    id: any;
    jsonrpc: string;
    error: any;
};
declare function isJsonRpcResult(payload: any): boolean;
declare function isJsonRpcError(payload: any): boolean;
declare function payloadId(entropy?: number): number;
declare let f$2: {
    new (t8: any, e8?: boolean): {
        url: any;
        disableProviderPing: boolean;
        events: any;
        isAvailable: boolean;
        registering: boolean;
        get connected(): boolean;
        get connecting(): boolean;
        on(t8: any, e8: any): void;
        once(t8: any, e8: any): void;
        off(t8: any, e8: any): void;
        removeListener(t8: any, e8: any): void;
        open(t8?: any): Promise<void>;
        close(): Promise<void>;
        send(t8: any): Promise<void>;
        register(t8?: any): Promise<any>;
        onOpen(): void;
        onClose(): void;
        onPayload(t8: any): void;
        onError(t8: any, e8: any): void;
        parseError(t8: any, e8?: any): any;
        resetMaxListeners(): void;
    };
};
declare function getUrl$1(url: any): any;
declare function hexToString(hex2: any, opts?: {}): string;
declare function decodeAbiParameters(params: any, data: any): any[];
declare const erc20Abi: ({
    type: string;
    name: string;
    inputs: {
        indexed: boolean;
        name: string;
        type: string;
    }[];
    stateMutability?: undefined;
    outputs?: undefined;
} | {
    type: string;
    name: string;
    stateMutability: string;
    inputs: {
        name: string;
        type: string;
    }[];
    outputs: {
        type: string;
    }[];
})[];
declare function hexToNumber$2(hex2: any, opts?: {}): number;
declare function isAddressEqual(a7: any, b2: any): boolean;
declare function decodeEventLog(parameters: any): {
    eventName: any;
    args: {};
};
declare function formatUnits(value: any, decimals: any): string;
declare function parseUnits$1(value: any, decimals: any): bigint;
declare function createTransport({ key: key2, methods, name, request, retryCount, retryDelay, timeout, type: type2 }: {
    key: any;
    methods: any;
    name: any;
    request: any;
    retryCount?: number;
    retryDelay?: number;
    timeout: any;
    type: any;
}, value: any): {
    config: {
        key: any;
        methods: any;
        name: any;
        request: any;
        retryCount: number;
        retryDelay: number;
        timeout: any;
        type: any;
    };
    request: (args: any, overrideOptions?: {}) => Promise<any>;
    value: any;
};
declare class TransactionRejectedRpcError extends RpcError {
    constructor(cause: any);
}
declare namespace TransactionRejectedRpcError {
    let code: number;
}
declare class UserRejectedRequestError extends ProviderRpcError {
    constructor(cause: any);
}
declare namespace UserRejectedRequestError {
    let code_1: number;
    export { code_1 as code };
}
declare const ExecutionRevertedError_base: {
    new (shortMessage: any, args?: {}): {
        details: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
        version: string;
        walk(fn6: any): any;
        message: string;
        stack?: string;
        cause?: unknown;
    };
    isError(error: unknown): error is Error;
    captureStackTrace(targetObject: object, constructorOpt?: Function): void;
    prepareStackTrace(err: Error, stackTraces: NodeJS.CallSite[]): any;
    stackTraceLimit: number;
};
declare class ExecutionRevertedError extends ExecutionRevertedError_base {
    constructor({ cause, message }?: {});
}
declare namespace ExecutionRevertedError {
    let code_2: number;
    export { code_2 as code };
    export let nodeMessage: RegExp;
}
declare function wait(time2: any): Promise<any>;
declare class IEvents {
}
declare function __vitePreload(baseModule: any, deps: any, importerUrl: any): Promise<any>;
declare namespace bases {
    export let __proto__: any;
    export { base256emoji };
    export { base64 };
    export { base64pad };
    export { base64url };
    export { base64urlpad };
    export { base58btc };
    export { base58flickr };
    export { base36 };
    export { base36upper };
    export { base32 };
    export { base32hex };
    export { base32hexpad };
    export { base32hexpadupper };
    export { base32hexupper };
    export { base32pad };
    export { base32padupper };
    export { base32upper };
    export { base32z };
    export { base16 };
    export { base16upper };
    export { base10 };
    export { base8 };
    export { base2 };
    export { identity };
}
declare var getWindowMetadata_1: any;
declare var cjs$3: {};
declare function getDocument_1(): any;
declare namespace C$4 {
    namespace waku {
        let publish: string;
        let batchPublish: string;
        let subscribe: string;
        let batchSubscribe: string;
        let subscription: string;
        let unsubscribe: string;
        let batchUnsubscribe: string;
        let batchFetchMessages: string;
    }
    namespace irn {
        let publish_1: string;
        export { publish_1 as publish };
        let batchPublish_1: string;
        export { batchPublish_1 as batchPublish };
        let subscribe_1: string;
        export { subscribe_1 as subscribe };
        let batchSubscribe_1: string;
        export { batchSubscribe_1 as batchSubscribe };
        let subscription_1: string;
        export { subscription_1 as subscription };
        let unsubscribe_1: string;
        export { unsubscribe_1 as unsubscribe };
        let batchUnsubscribe_1: string;
        export { batchUnsubscribe_1 as batchUnsubscribe };
        let batchFetchMessages_1: string;
        export { batchFetchMessages_1 as batchFetchMessages };
    }
    namespace iridium {
        let publish_2: string;
        export { publish_2 as publish };
        let batchPublish_2: string;
        export { batchPublish_2 as batchPublish };
        let subscribe_2: string;
        export { subscribe_2 as subscribe };
        let batchSubscribe_2: string;
        export { batchSubscribe_2 as batchSubscribe };
        let subscription_2: string;
        export { subscription_2 as subscription };
        let unsubscribe_2: string;
        export { unsubscribe_2 as unsubscribe };
        let batchUnsubscribe_2: string;
        export { batchUnsubscribe_2 as batchUnsubscribe };
        let batchFetchMessages_2: string;
        export { batchFetchMessages_2 as batchFetchMessages };
    }
}
declare function getNavigator_1(): any;
declare function detect(userAgent: any): any;
declare function getLocation_1(): any;
declare function sn$2(t8: any): {
    header: any;
    payload: any;
    signature: any;
    data: any;
};
declare namespace bs58 {
    export { encode5 as encode };
    export { decodeUnsafe2 as decodeUnsafe };
    export { decode3 as decode };
}
declare var eventsExports: {};
declare function boolToHex$1(value: any, opts?: {}): any;
declare function localBatchGatewayRequest(parameters: any): Promise<string | Uint8Array<ArrayBuffer>>;
declare function call(client2: any, args: any): Promise<{
    data: any;
}>;
declare const HttpRequestError_base: {
    new (shortMessage: any, args?: {}): {
        details: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
        version: string;
        walk(fn6: any): any;
        message: string;
        stack?: string;
        cause?: unknown;
    };
    isError(error: unknown): error is Error;
    captureStackTrace(targetObject: object, constructorOpt?: Function): void;
    prepareStackTrace(err: Error, stackTraces: NodeJS.CallSite[]): any;
    stackTraceLimit: number;
};
declare class HttpRequestError extends HttpRequestError_base {
    constructor({ body, cause, details, headers, status, url }: {
        body: any;
        cause: any;
        details: any;
        headers: any;
        status: any;
        url: any;
    });
    body: any;
    headers: any;
    status: any;
    url: any;
}
declare var dijkstraExports: {};
declare function concatHex(values: any): string;
declare const bytesRegex$1: RegExp;
declare const arrayRegex$1: RegExp;
declare function encodeAbiParameters(params: any, values: any): string | Uint8Array<ArrayBuffer>;
declare namespace secp256k1 {
    export { create3 as create };
    export { CURVE };
    export { getPublicKey2 as getPublicKey };
    export { getSharedSecret };
    export { sign4 as sign };
    export { verify3 as verify };
    export { Point2 as ProjectivePoint };
    export { Signature2 as Signature };
    export { utils2 as utils };
}
declare function hexToBytes$2(hex_: any, opts?: {}): Uint8Array<ArrayBuffer>;
declare function isAddress(address: any, options: any): any;
declare function clsx$1(...args: any[]): string;
declare function concat$3(values: any): string | Uint8Array<ArrayBuffer>;
declare function size$7(value: any): any;
declare function hashTypedData(parameters: any): any;
declare function numberToHex$1(value_: any, opts?: {}): any;
declare function keccak256$3(value: any, to_: any): any;
declare function pad$3(hexOrBytes: any, { dir, size: size2 }?: {
    size?: number;
}): any;
declare function getAction(client2: any, actionFn: any, name: any): any;
declare function getCode(client2: any, { address, blockNumber, blockTag }: {
    address: any;
    blockNumber: any;
    blockTag?: string;
}): Promise<any>;
declare function stringToHex$1(value_: any, opts?: {}): any;
declare function readContract(client2: any, parameters: any): Promise<any>;
declare function parseAbi(signatures: any): ({
    name: any;
    type: string;
    inputs: ({
        type: string;
        name?: undefined;
        indexed?: undefined;
    } | {
        indexed: boolean;
        name: any;
        type: string;
    } | {
        indexed?: undefined;
        name: any;
        type: string;
    } | {
        indexed: boolean;
        name?: undefined;
        type: string;
    })[];
} | {
    type: string;
    stateMutability: any;
})[];
declare let BaseError$2: {
    new (shortMessage: any, args?: {}): {
        details: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
        version: string;
        walk(fn6: any): any;
        message: string;
        stack?: string;
        cause?: unknown;
    };
    isError(error: unknown): error is Error;
    captureStackTrace(targetObject: object, constructorOpt?: Function): void;
    prepareStackTrace(err: Error, stackTraces: NodeJS.CallSite[]): any;
    stackTraceLimit: number;
};
declare function prettyPrint(args: any): string;
declare function formatGwei(wei: any, unit?: string): string;
declare function decodeErrorResult(parameters: any): {
    abiItem: any;
    args: any[];
    errorName: any;
};
declare const ContractFunctionRevertedError_base: {
    new (shortMessage: any, args?: {}): {
        details: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
        version: string;
        walk(fn6: any): any;
        message: string;
        stack?: string;
        cause?: unknown;
    };
    isError(error: unknown): error is Error;
    captureStackTrace(targetObject: object, constructorOpt?: Function): void;
    prepareStackTrace(err: Error, stackTraces: NodeJS.CallSite[]): any;
    stackTraceLimit: number;
};
declare class ContractFunctionRevertedError extends ContractFunctionRevertedError_base {
    constructor({ abi: abi2, data, functionName, message }: {
        abi: any;
        data: any;
        functionName: any;
        message: any;
    });
    data: {
        abiItem: any;
        args: any[];
        errorName: any;
    };
    raw: any;
    reason: any;
    signature: any;
}
declare const RpcError_base: {
    new (shortMessage: any, args?: {}): {
        details: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
        version: string;
        walk(fn6: any): any;
        message: string;
        stack?: string;
        cause?: unknown;
    };
    isError(error: unknown): error is Error;
    captureStackTrace(targetObject: object, constructorOpt?: Function): void;
    prepareStackTrace(err: Error, stackTraces: NodeJS.CallSite[]): any;
    stackTraceLimit: number;
};
declare class RpcError extends RpcError_base {
    constructor(cause: any, { code: code2, docsPath: docsPath2, metaMessages, name, shortMessage }: {
        code: any;
        docsPath: any;
        metaMessages: any;
        name: any;
        shortMessage: any;
    });
    code: any;
}
declare class ProviderRpcError extends RpcError {
    constructor(cause: any, options: any);
    data: any;
}
declare const base256emoji: Codec;
declare const base64: Codec;
declare const base64pad: Codec;
declare const base64url: Codec;
declare const base64urlpad: Codec;
declare const base58btc: Codec;
declare const base58flickr: Codec;
declare const base36: Codec;
declare const base36upper: Codec;
declare const base32: Codec;
declare const base32hex: Codec;
declare const base32hexpad: Codec;
declare const base32hexpadupper: Codec;
declare const base32hexupper: Codec;
declare const base32pad: Codec;
declare const base32padupper: Codec;
declare const base32upper: Codec;
declare const base32z: Codec;
declare const base16: Codec;
declare const base16upper: Codec;
declare const base10: Codec;
declare const base8: Codec;
declare const base2: Codec;
declare const identity: Codec;
declare function encode5(source: any): any;
declare function decodeUnsafe2(source: any): Uint8Array<ArrayBuffer>;
declare function decode3(string2: any): Uint8Array<ArrayBuffer>;
declare function create3(hash2: any): {
    CURVE: any;
    getPublicKey: (privateKey: any, isCompressed?: boolean) => any;
    getSharedSecret: (privateA: any, publicB: any, isCompressed?: boolean) => any;
    sign: (msgHash: any, privKey: any, opts?: {
        lowS: any;
        prehash: boolean;
    }) => any;
    verify: (signature2: any, msgHash: any, publicKey2: any, opts?: {
        lowS: any;
        prehash: boolean;
    }) => boolean;
    ProjectivePoint: {
        new (px2: any, py2: any, pz: any): {
            px: any;
            py: any;
            pz: any;
            get x(): any;
            get y(): any;
            _setWindowSize(windowSize: any): void;
            assertValidity(): void;
            hasEvenY(): boolean;
            /**
             * Compare one point to another.
             */
            equals(other: any): any;
            /**
             * Flips point to one corresponding to (x, -y) in Affine coordinates.
             */
            negate(): /*elided*/ any;
            double(): /*elided*/ any;
            add(other: any): /*elided*/ any;
            subtract(other: any): /*elided*/ any;
            is0(): any;
            wNAF(n6: any): {
                p: any;
                f: any;
            };
            /**
             * Non-constant-time multiplication. Uses double-and-add algorithm.
             * It's faster, but should only be used when you don't care about
             * an exposed private key e.g. sig verification, which works over *public* keys.
             */
            multiplyUnsafe(sc2: any): any;
            /**
             * Constant time multiplication.
             * Uses wNAF method. Windowed method may be 10% faster,
             * but takes 2x longer to generate and consumes 2x memory.
             * Uses precomputes when available.
             * Uses endomorphism for Koblitz curves.
             * @param scalar by which the point would be multiplied
             * @returns New point
             */
            multiply(scalar: any): any;
            /**
             * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
             * Not using Strauss-Shamir trick: precomputation tables are faster.
             * The trick could be useful if both P and Q are not G (not in our case).
             * @returns non-zero affine point
             */
            multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
            toAffine(iz: any): any;
            isTorsionFree(): any;
            clearCofactor(): any;
            toRawBytes(isCompressed?: boolean): any;
            toHex(isCompressed?: boolean): any;
        };
        fromAffine(p4: any): {
            px: any;
            py: any;
            pz: any;
            get x(): any;
            get y(): any;
            _setWindowSize(windowSize: any): void;
            assertValidity(): void;
            hasEvenY(): boolean;
            /**
             * Compare one point to another.
             */
            equals(other: any): any;
            /**
             * Flips point to one corresponding to (x, -y) in Affine coordinates.
             */
            negate(): /*elided*/ any;
            double(): /*elided*/ any;
            add(other: any): /*elided*/ any;
            subtract(other: any): /*elided*/ any;
            is0(): any;
            wNAF(n6: any): {
                p: any;
                f: any;
            };
            /**
             * Non-constant-time multiplication. Uses double-and-add algorithm.
             * It's faster, but should only be used when you don't care about
             * an exposed private key e.g. sig verification, which works over *public* keys.
             */
            multiplyUnsafe(sc2: any): any;
            /**
             * Constant time multiplication.
             * Uses wNAF method. Windowed method may be 10% faster,
             * but takes 2x longer to generate and consumes 2x memory.
             * Uses precomputes when available.
             * Uses endomorphism for Koblitz curves.
             * @param scalar by which the point would be multiplied
             * @returns New point
             */
            multiply(scalar: any): any;
            /**
             * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
             * Not using Strauss-Shamir trick: precomputation tables are faster.
             * The trick could be useful if both P and Q are not G (not in our case).
             * @returns non-zero affine point
             */
            multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
            toAffine(iz: any): any;
            isTorsionFree(): any;
            clearCofactor(): any;
            toRawBytes(isCompressed?: boolean): any;
            toHex(isCompressed?: boolean): any;
        };
        /**
         * Takes a bunch of Projective Points but executes only one
         * inversion on all of them. Inversion is very slow operation,
         * so this improves performance massively.
         * Optimization: converts a list of projective points to a list of identical points with Z=1.
         */
        normalizeZ(points: any): any;
        /**
         * Converts hash string or Uint8Array to Point.
         * @param hex short/long ECDSA hex
         */
        fromHex(hex2: any): {
            px: any;
            py: any;
            pz: any;
            get x(): any;
            get y(): any;
            _setWindowSize(windowSize: any): void;
            assertValidity(): void;
            hasEvenY(): boolean;
            /**
             * Compare one point to another.
             */
            equals(other: any): any;
            /**
             * Flips point to one corresponding to (x, -y) in Affine coordinates.
             */
            negate(): /*elided*/ any;
            double(): /*elided*/ any;
            add(other: any): /*elided*/ any;
            subtract(other: any): /*elided*/ any;
            is0(): any;
            wNAF(n6: any): {
                p: any;
                f: any;
            };
            /**
             * Non-constant-time multiplication. Uses double-and-add algorithm.
             * It's faster, but should only be used when you don't care about
             * an exposed private key e.g. sig verification, which works over *public* keys.
             */
            multiplyUnsafe(sc2: any): any;
            /**
             * Constant time multiplication.
             * Uses wNAF method. Windowed method may be 10% faster,
             * but takes 2x longer to generate and consumes 2x memory.
             * Uses precomputes when available.
             * Uses endomorphism for Koblitz curves.
             * @param scalar by which the point would be multiplied
             * @returns New point
             */
            multiply(scalar: any): any;
            /**
             * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
             * Not using Strauss-Shamir trick: precomputation tables are faster.
             * The trick could be useful if both P and Q are not G (not in our case).
             * @returns non-zero affine point
             */
            multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
            toAffine(iz: any): any;
            isTorsionFree(): any;
            clearCofactor(): any;
            toRawBytes(isCompressed?: boolean): any;
            toHex(isCompressed?: boolean): any;
        };
        fromPrivateKey(privateKey: any): any;
        msm(points: any, scalars: any): any;
        BASE: {
            px: any;
            py: any;
            pz: any;
            get x(): any;
            get y(): any;
            _setWindowSize(windowSize: any): void;
            assertValidity(): void;
            hasEvenY(): boolean;
            /**
             * Compare one point to another.
             */
            equals(other: any): any;
            /**
             * Flips point to one corresponding to (x, -y) in Affine coordinates.
             */
            negate(): /*elided*/ any;
            double(): /*elided*/ any;
            add(other: any): /*elided*/ any;
            subtract(other: any): /*elided*/ any;
            is0(): any;
            wNAF(n6: any): {
                p: any;
                f: any;
            };
            /**
             * Non-constant-time multiplication. Uses double-and-add algorithm.
             * It's faster, but should only be used when you don't care about
             * an exposed private key e.g. sig verification, which works over *public* keys.
             */
            multiplyUnsafe(sc2: any): any;
            /**
             * Constant time multiplication.
             * Uses wNAF method. Windowed method may be 10% faster,
             * but takes 2x longer to generate and consumes 2x memory.
             * Uses precomputes when available.
             * Uses endomorphism for Koblitz curves.
             * @param scalar by which the point would be multiplied
             * @returns New point
             */
            multiply(scalar: any): any;
            /**
             * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
             * Not using Strauss-Shamir trick: precomputation tables are faster.
             * The trick could be useful if both P and Q are not G (not in our case).
             * @returns non-zero affine point
             */
            multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
            toAffine(iz: any): any;
            isTorsionFree(): any;
            clearCofactor(): any;
            toRawBytes(isCompressed?: boolean): any;
            toHex(isCompressed?: boolean): any;
        };
        ZERO: {
            px: any;
            py: any;
            pz: any;
            get x(): any;
            get y(): any;
            _setWindowSize(windowSize: any): void;
            assertValidity(): void;
            hasEvenY(): boolean;
            /**
             * Compare one point to another.
             */
            equals(other: any): any;
            /**
             * Flips point to one corresponding to (x, -y) in Affine coordinates.
             */
            negate(): /*elided*/ any;
            double(): /*elided*/ any;
            add(other: any): /*elided*/ any;
            subtract(other: any): /*elided*/ any;
            is0(): any;
            wNAF(n6: any): {
                p: any;
                f: any;
            };
            /**
             * Non-constant-time multiplication. Uses double-and-add algorithm.
             * It's faster, but should only be used when you don't care about
             * an exposed private key e.g. sig verification, which works over *public* keys.
             */
            multiplyUnsafe(sc2: any): any;
            /**
             * Constant time multiplication.
             * Uses wNAF method. Windowed method may be 10% faster,
             * but takes 2x longer to generate and consumes 2x memory.
             * Uses precomputes when available.
             * Uses endomorphism for Koblitz curves.
             * @param scalar by which the point would be multiplied
             * @returns New point
             */
            multiply(scalar: any): any;
            /**
             * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
             * Not using Strauss-Shamir trick: precomputation tables are faster.
             * The trick could be useful if both P and Q are not G (not in our case).
             * @returns non-zero affine point
             */
            multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
            toAffine(iz: any): any;
            isTorsionFree(): any;
            clearCofactor(): any;
            toRawBytes(isCompressed?: boolean): any;
            toHex(isCompressed?: boolean): any;
        };
    };
    Signature: {
        new (r8: any, s5: any, recovery: any): {
            r: any;
            s: any;
            recovery: any;
            /**
             * @todo remove
             * @deprecated
             */
            assertValidity(): void;
            addRecoveryBit(recovery: any): /*elided*/ any;
            recoverPublicKey(msgHash: any): any;
            hasHighS(): boolean;
            normalizeS(): /*elided*/ any;
            toDERRawBytes(): any;
            toDERHex(): any;
            toCompactRawBytes(): any;
            toCompactHex(): any;
        };
        fromCompact(hex2: any): {
            r: any;
            s: any;
            recovery: any;
            /**
             * @todo remove
             * @deprecated
             */
            assertValidity(): void;
            addRecoveryBit(recovery: any): /*elided*/ any;
            recoverPublicKey(msgHash: any): any;
            hasHighS(): boolean;
            normalizeS(): /*elided*/ any;
            toDERRawBytes(): any;
            toDERHex(): any;
            toCompactRawBytes(): any;
            toCompactHex(): any;
        };
        fromDER(hex2: any): {
            r: any;
            s: any;
            recovery: any;
            /**
             * @todo remove
             * @deprecated
             */
            assertValidity(): void;
            addRecoveryBit(recovery: any): /*elided*/ any;
            recoverPublicKey(msgHash: any): any;
            hasHighS(): boolean;
            normalizeS(): /*elided*/ any;
            toDERRawBytes(): any;
            toDERHex(): any;
            toCompactRawBytes(): any;
            toCompactHex(): any;
        };
    };
    utils: {
        isValidPrivateKey(privateKey: any): boolean;
        normPrivateKeyToScalar: (key2: any) => any;
        /**
         * Produces cryptographically secure private key from random of size
         * (groupLen + ceil(groupLen / 2)) with modulo bias being negligible.
         */
        randomPrivateKey: () => any;
        /**
         * Creates precompute table for an arbitrary EC point. Makes point "cached".
         * Allows to massively speed-up `point.multiply(scalar)`.
         * @returns cached point
         * @example
         * const fast = utils.precompute(8, ProjectivePoint.fromHex(someonesPubKey));
         * fast.multiply(privKey); // much faster ECDH now
         */
        precompute(windowSize?: number, point3?: {
            px: any;
            py: any;
            pz: any;
            get x(): any;
            get y(): any;
            _setWindowSize(windowSize: any): void;
            assertValidity(): void;
            hasEvenY(): boolean;
            /**
             * Compare one point to another.
             */
            equals(other: any): any;
            /**
             * Flips point to one corresponding to (x, -y) in Affine coordinates.
             */
            negate(): /*elided*/ any;
            double(): /*elided*/ any;
            add(other: any): /*elided*/ any;
            subtract(other: any): /*elided*/ any;
            is0(): any;
            wNAF(n6: any): {
                p: any;
                f: any;
            };
            /**
             * Non-constant-time multiplication. Uses double-and-add algorithm.
             * It's faster, but should only be used when you don't care about
             * an exposed private key e.g. sig verification, which works over *public* keys.
             */
            multiplyUnsafe(sc2: any): any;
            /**
             * Constant time multiplication.
             * Uses wNAF method. Windowed method may be 10% faster,
             * but takes 2x longer to generate and consumes 2x memory.
             * Uses precomputes when available.
             * Uses endomorphism for Koblitz curves.
             * @param scalar by which the point would be multiplied
             * @returns New point
             */
            multiply(scalar: any): any;
            /**
             * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
             * Not using Strauss-Shamir trick: precomputation tables are faster.
             * The trick could be useful if both P and Q are not G (not in our case).
             * @returns non-zero affine point
             */
            multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
            toAffine(iz: any): any;
            isTorsionFree(): any;
            clearCofactor(): any;
            toRawBytes(isCompressed?: boolean): any;
            toHex(isCompressed?: boolean): any;
        }): {
            px: any;
            py: any;
            pz: any;
            get x(): any;
            get y(): any;
            _setWindowSize(windowSize: any): void;
            assertValidity(): void;
            hasEvenY(): boolean;
            /**
             * Compare one point to another.
             */
            equals(other: any): any;
            /**
             * Flips point to one corresponding to (x, -y) in Affine coordinates.
             */
            negate(): /*elided*/ any;
            double(): /*elided*/ any;
            add(other: any): /*elided*/ any;
            subtract(other: any): /*elided*/ any;
            is0(): any;
            wNAF(n6: any): {
                p: any;
                f: any;
            };
            /**
             * Non-constant-time multiplication. Uses double-and-add algorithm.
             * It's faster, but should only be used when you don't care about
             * an exposed private key e.g. sig verification, which works over *public* keys.
             */
            multiplyUnsafe(sc2: any): any;
            /**
             * Constant time multiplication.
             * Uses wNAF method. Windowed method may be 10% faster,
             * but takes 2x longer to generate and consumes 2x memory.
             * Uses precomputes when available.
             * Uses endomorphism for Koblitz curves.
             * @param scalar by which the point would be multiplied
             * @returns New point
             */
            multiply(scalar: any): any;
            /**
             * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
             * Not using Strauss-Shamir trick: precomputation tables are faster.
             * The trick could be useful if both P and Q are not G (not in our case).
             * @returns non-zero affine point
             */
            multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
            toAffine(iz: any): any;
            isTorsionFree(): any;
            clearCofactor(): any;
            toRawBytes(isCompressed?: boolean): any;
            toHex(isCompressed?: boolean): any;
        };
    };
};
declare const CURVE: any;
declare function getPublicKey2(privateKey: any, isCompressed?: boolean): any;
declare function getSharedSecret(privateA: any, publicB: any, isCompressed?: boolean): any;
declare function sign4(msgHash: any, privKey: any, opts?: {
    lowS: any;
    prehash: boolean;
}): any;
declare function verify3(signature2: any, msgHash: any, publicKey2: any, opts?: {
    lowS: any;
    prehash: boolean;
}): boolean;
declare const Point2: {
    new (px2: any, py2: any, pz: any): {
        px: any;
        py: any;
        pz: any;
        get x(): any;
        get y(): any;
        _setWindowSize(windowSize: any): void;
        assertValidity(): void;
        hasEvenY(): boolean;
        /**
         * Compare one point to another.
         */
        equals(other: any): any;
        /**
         * Flips point to one corresponding to (x, -y) in Affine coordinates.
         */
        negate(): /*elided*/ any;
        double(): /*elided*/ any;
        add(other: any): /*elided*/ any;
        subtract(other: any): /*elided*/ any;
        is0(): any;
        wNAF(n6: any): {
            p: any;
            f: any;
        };
        /**
         * Non-constant-time multiplication. Uses double-and-add algorithm.
         * It's faster, but should only be used when you don't care about
         * an exposed private key e.g. sig verification, which works over *public* keys.
         */
        multiplyUnsafe(sc2: any): any;
        /**
         * Constant time multiplication.
         * Uses wNAF method. Windowed method may be 10% faster,
         * but takes 2x longer to generate and consumes 2x memory.
         * Uses precomputes when available.
         * Uses endomorphism for Koblitz curves.
         * @param scalar by which the point would be multiplied
         * @returns New point
         */
        multiply(scalar: any): any;
        /**
         * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
         * Not using Strauss-Shamir trick: precomputation tables are faster.
         * The trick could be useful if both P and Q are not G (not in our case).
         * @returns non-zero affine point
         */
        multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
        toAffine(iz: any): any;
        isTorsionFree(): any;
        clearCofactor(): any;
        toRawBytes(isCompressed?: boolean): any;
        toHex(isCompressed?: boolean): any;
    };
    fromAffine(p4: any): {
        px: any;
        py: any;
        pz: any;
        get x(): any;
        get y(): any;
        _setWindowSize(windowSize: any): void;
        assertValidity(): void;
        hasEvenY(): boolean;
        /**
         * Compare one point to another.
         */
        equals(other: any): any;
        /**
         * Flips point to one corresponding to (x, -y) in Affine coordinates.
         */
        negate(): /*elided*/ any;
        double(): /*elided*/ any;
        add(other: any): /*elided*/ any;
        subtract(other: any): /*elided*/ any;
        is0(): any;
        wNAF(n6: any): {
            p: any;
            f: any;
        };
        /**
         * Non-constant-time multiplication. Uses double-and-add algorithm.
         * It's faster, but should only be used when you don't care about
         * an exposed private key e.g. sig verification, which works over *public* keys.
         */
        multiplyUnsafe(sc2: any): any;
        /**
         * Constant time multiplication.
         * Uses wNAF method. Windowed method may be 10% faster,
         * but takes 2x longer to generate and consumes 2x memory.
         * Uses precomputes when available.
         * Uses endomorphism for Koblitz curves.
         * @param scalar by which the point would be multiplied
         * @returns New point
         */
        multiply(scalar: any): any;
        /**
         * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
         * Not using Strauss-Shamir trick: precomputation tables are faster.
         * The trick could be useful if both P and Q are not G (not in our case).
         * @returns non-zero affine point
         */
        multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
        toAffine(iz: any): any;
        isTorsionFree(): any;
        clearCofactor(): any;
        toRawBytes(isCompressed?: boolean): any;
        toHex(isCompressed?: boolean): any;
    };
    /**
     * Takes a bunch of Projective Points but executes only one
     * inversion on all of them. Inversion is very slow operation,
     * so this improves performance massively.
     * Optimization: converts a list of projective points to a list of identical points with Z=1.
     */
    normalizeZ(points: any): any;
    /**
     * Converts hash string or Uint8Array to Point.
     * @param hex short/long ECDSA hex
     */
    fromHex(hex2: any): {
        px: any;
        py: any;
        pz: any;
        get x(): any;
        get y(): any;
        _setWindowSize(windowSize: any): void;
        assertValidity(): void;
        hasEvenY(): boolean;
        /**
         * Compare one point to another.
         */
        equals(other: any): any;
        /**
         * Flips point to one corresponding to (x, -y) in Affine coordinates.
         */
        negate(): /*elided*/ any;
        double(): /*elided*/ any;
        add(other: any): /*elided*/ any;
        subtract(other: any): /*elided*/ any;
        is0(): any;
        wNAF(n6: any): {
            p: any;
            f: any;
        };
        /**
         * Non-constant-time multiplication. Uses double-and-add algorithm.
         * It's faster, but should only be used when you don't care about
         * an exposed private key e.g. sig verification, which works over *public* keys.
         */
        multiplyUnsafe(sc2: any): any;
        /**
         * Constant time multiplication.
         * Uses wNAF method. Windowed method may be 10% faster,
         * but takes 2x longer to generate and consumes 2x memory.
         * Uses precomputes when available.
         * Uses endomorphism for Koblitz curves.
         * @param scalar by which the point would be multiplied
         * @returns New point
         */
        multiply(scalar: any): any;
        /**
         * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
         * Not using Strauss-Shamir trick: precomputation tables are faster.
         * The trick could be useful if both P and Q are not G (not in our case).
         * @returns non-zero affine point
         */
        multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
        toAffine(iz: any): any;
        isTorsionFree(): any;
        clearCofactor(): any;
        toRawBytes(isCompressed?: boolean): any;
        toHex(isCompressed?: boolean): any;
    };
    fromPrivateKey(privateKey: any): any;
    msm(points: any, scalars: any): any;
    BASE: {
        px: any;
        py: any;
        pz: any;
        get x(): any;
        get y(): any;
        _setWindowSize(windowSize: any): void;
        assertValidity(): void;
        hasEvenY(): boolean;
        /**
         * Compare one point to another.
         */
        equals(other: any): any;
        /**
         * Flips point to one corresponding to (x, -y) in Affine coordinates.
         */
        negate(): /*elided*/ any;
        double(): /*elided*/ any;
        add(other: any): /*elided*/ any;
        subtract(other: any): /*elided*/ any;
        is0(): any;
        wNAF(n6: any): {
            p: any;
            f: any;
        };
        /**
         * Non-constant-time multiplication. Uses double-and-add algorithm.
         * It's faster, but should only be used when you don't care about
         * an exposed private key e.g. sig verification, which works over *public* keys.
         */
        multiplyUnsafe(sc2: any): any;
        /**
         * Constant time multiplication.
         * Uses wNAF method. Windowed method may be 10% faster,
         * but takes 2x longer to generate and consumes 2x memory.
         * Uses precomputes when available.
         * Uses endomorphism for Koblitz curves.
         * @param scalar by which the point would be multiplied
         * @returns New point
         */
        multiply(scalar: any): any;
        /**
         * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
         * Not using Strauss-Shamir trick: precomputation tables are faster.
         * The trick could be useful if both P and Q are not G (not in our case).
         * @returns non-zero affine point
         */
        multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
        toAffine(iz: any): any;
        isTorsionFree(): any;
        clearCofactor(): any;
        toRawBytes(isCompressed?: boolean): any;
        toHex(isCompressed?: boolean): any;
    };
    ZERO: {
        px: any;
        py: any;
        pz: any;
        get x(): any;
        get y(): any;
        _setWindowSize(windowSize: any): void;
        assertValidity(): void;
        hasEvenY(): boolean;
        /**
         * Compare one point to another.
         */
        equals(other: any): any;
        /**
         * Flips point to one corresponding to (x, -y) in Affine coordinates.
         */
        negate(): /*elided*/ any;
        double(): /*elided*/ any;
        add(other: any): /*elided*/ any;
        subtract(other: any): /*elided*/ any;
        is0(): any;
        wNAF(n6: any): {
            p: any;
            f: any;
        };
        /**
         * Non-constant-time multiplication. Uses double-and-add algorithm.
         * It's faster, but should only be used when you don't care about
         * an exposed private key e.g. sig verification, which works over *public* keys.
         */
        multiplyUnsafe(sc2: any): any;
        /**
         * Constant time multiplication.
         * Uses wNAF method. Windowed method may be 10% faster,
         * but takes 2x longer to generate and consumes 2x memory.
         * Uses precomputes when available.
         * Uses endomorphism for Koblitz curves.
         * @param scalar by which the point would be multiplied
         * @returns New point
         */
        multiply(scalar: any): any;
        /**
         * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
         * Not using Strauss-Shamir trick: precomputation tables are faster.
         * The trick could be useful if both P and Q are not G (not in our case).
         * @returns non-zero affine point
         */
        multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
        toAffine(iz: any): any;
        isTorsionFree(): any;
        clearCofactor(): any;
        toRawBytes(isCompressed?: boolean): any;
        toHex(isCompressed?: boolean): any;
    };
};
declare class Signature2 {
    static fromCompact(hex2: any): {
        r: any;
        s: any;
        recovery: any;
        /**
         * @todo remove
         * @deprecated
         */
        assertValidity(): void;
        addRecoveryBit(recovery: any): /*elided*/ any;
        recoverPublicKey(msgHash: any): any;
        hasHighS(): boolean;
        normalizeS(): /*elided*/ any;
        toDERRawBytes(): any;
        toDERHex(): any;
        toCompactRawBytes(): any;
        toCompactHex(): any;
    };
    static fromDER(hex2: any): {
        r: any;
        s: any;
        recovery: any;
        /**
         * @todo remove
         * @deprecated
         */
        assertValidity(): void;
        addRecoveryBit(recovery: any): /*elided*/ any;
        recoverPublicKey(msgHash: any): any;
        hasHighS(): boolean;
        normalizeS(): /*elided*/ any;
        toDERRawBytes(): any;
        toDERHex(): any;
        toCompactRawBytes(): any;
        toCompactHex(): any;
    };
    constructor(r8: any, s5: any, recovery: any);
    r: any;
    s: any;
    recovery: any;
    /**
     * @todo remove
     * @deprecated
     */
    assertValidity(): void;
    addRecoveryBit(recovery: any): {
        r: any;
        s: any;
        recovery: any;
        /**
         * @todo remove
         * @deprecated
         */
        assertValidity(): void;
        addRecoveryBit(recovery: any): /*elided*/ any;
        recoverPublicKey(msgHash: any): any;
        hasHighS(): boolean;
        normalizeS(): /*elided*/ any;
        toDERRawBytes(): any;
        toDERHex(): any;
        toCompactRawBytes(): any;
        toCompactHex(): any;
    };
    recoverPublicKey(msgHash: any): any;
    hasHighS(): boolean;
    normalizeS(): {
        r: any;
        s: any;
        recovery: any;
        /**
         * @todo remove
         * @deprecated
         */
        assertValidity(): void;
        addRecoveryBit(recovery: any): /*elided*/ any;
        recoverPublicKey(msgHash: any): any;
        hasHighS(): boolean;
        normalizeS(): /*elided*/ any;
        toDERRawBytes(): any;
        toDERHex(): any;
        toCompactRawBytes(): any;
        toCompactHex(): any;
    };
    toDERRawBytes(): any;
    toDERHex(): any;
    toCompactRawBytes(): any;
    toCompactHex(): any;
}
declare namespace utils2 {
    export function isValidPrivateKey(privateKey: any): boolean;
    export { normPrivateKeyToScalar };
    export function randomPrivateKey(): any;
    /**
     * Creates precompute table for an arbitrary EC point. Makes point "cached".
     * Allows to massively speed-up `point.multiply(scalar)`.
     * @returns cached point
     * @example
     * const fast = utils.precompute(8, ProjectivePoint.fromHex(someonesPubKey));
     * fast.multiply(privKey); // much faster ECDH now
     */
    export function precompute(windowSize?: number, point3?: {
        px: any;
        py: any;
        pz: any;
        get x(): any;
        get y(): any;
        _setWindowSize(windowSize: any): void;
        assertValidity(): void;
        hasEvenY(): boolean;
        /**
         * Compare one point to another.
         */
        equals(other: any): any;
        /**
         * Flips point to one corresponding to (x, -y) in Affine coordinates.
         */
        negate(): /*elided*/ any;
        double(): /*elided*/ any;
        add(other: any): /*elided*/ any;
        subtract(other: any): /*elided*/ any;
        is0(): any;
        wNAF(n6: any): {
            p: any;
            f: any;
        };
        /**
         * Non-constant-time multiplication. Uses double-and-add algorithm.
         * It's faster, but should only be used when you don't care about
         * an exposed private key e.g. sig verification, which works over *public* keys.
         */
        multiplyUnsafe(sc2: any): any;
        /**
         * Constant time multiplication.
         * Uses wNAF method. Windowed method may be 10% faster,
         * but takes 2x longer to generate and consumes 2x memory.
         * Uses precomputes when available.
         * Uses endomorphism for Koblitz curves.
         * @param scalar by which the point would be multiplied
         * @returns New point
         */
        multiply(scalar: any): any;
        /**
         * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
         * Not using Strauss-Shamir trick: precomputation tables are faster.
         * The trick could be useful if both P and Q are not G (not in our case).
         * @returns non-zero affine point
         */
        multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
        toAffine(iz: any): any;
        isTorsionFree(): any;
        clearCofactor(): any;
        toRawBytes(isCompressed?: boolean): any;
        toHex(isCompressed?: boolean): any;
    }): {
        px: any;
        py: any;
        pz: any;
        get x(): any;
        get y(): any;
        _setWindowSize(windowSize: any): void;
        assertValidity(): void;
        hasEvenY(): boolean;
        /**
         * Compare one point to another.
         */
        equals(other: any): any;
        /**
         * Flips point to one corresponding to (x, -y) in Affine coordinates.
         */
        negate(): /*elided*/ any;
        double(): /*elided*/ any;
        add(other: any): /*elided*/ any;
        subtract(other: any): /*elided*/ any;
        is0(): any;
        wNAF(n6: any): {
            p: any;
            f: any;
        };
        /**
         * Non-constant-time multiplication. Uses double-and-add algorithm.
         * It's faster, but should only be used when you don't care about
         * an exposed private key e.g. sig verification, which works over *public* keys.
         */
        multiplyUnsafe(sc2: any): any;
        /**
         * Constant time multiplication.
         * Uses wNAF method. Windowed method may be 10% faster,
         * but takes 2x longer to generate and consumes 2x memory.
         * Uses precomputes when available.
         * Uses endomorphism for Koblitz curves.
         * @param scalar by which the point would be multiplied
         * @returns New point
         */
        multiply(scalar: any): any;
        /**
         * Efficiently calculate `aP + bQ`. Unsafe, can expose private key, if used incorrectly.
         * Not using Strauss-Shamir trick: precomputation tables are faster.
         * The trick could be useful if both P and Q are not G (not in our case).
         * @returns non-zero affine point
         */
        multiplyAndAddUnsafe(Q2: any, a7: any, b2: any): any;
        toAffine(iz: any): any;
        isTorsionFree(): any;
        clearCofactor(): any;
        toRawBytes(isCompressed?: boolean): any;
        toHex(isCompressed?: boolean): any;
    };
}
declare class Codec {
    constructor(name: any, prefix2: any, baseEncode2: any, baseDecode2: any);
    name: any;
    prefix: any;
    baseEncode: any;
    baseDecode: any;
    encoder: Encoder2;
    decoder: Decoder2;
    encode(input: any): string;
    decode(input: any): any;
}
declare function normPrivateKeyToScalar(key2: any): any;
declare class Encoder2 {
    constructor(name: any, prefix2: any, baseEncode2: any);
    name: any;
    prefix: any;
    baseEncode: any;
    encode(bytes: any): string;
}
declare class Decoder2 {
    constructor(name: any, prefix2: any, baseDecode2: any);
    name: any;
    prefix: any;
    prefixCodePoint: any;
    baseDecode: any;
    decode(text: any): any;
    or(decoder2: any): ComposedDecoder;
}
declare class ComposedDecoder {
    constructor(decoders2: any);
    decoders: any;
    or(decoder2: any): ComposedDecoder;
    decode(input: any): any;
}
export { Field$1 as $, AbiEncodingLengthMismatchError as A, BytesSizeMismatchError$1 as B, ContractFunctionZeroDataError as C, ContractFunctionExecutionError as D, EventEmitter$1 as E, hexToBigInt$1 as F, AccountNotFoundError as G, encodeFunctionData as H, InvalidAddressError$1 as I, estimateFeesPerGas as J, prepareAuthorization as K, LruMap$2 as L, parseAccount as M, getChainId as N, serializeStateOverride as O, formatLog as P, formatTransactionReceipt as Q, stringify$3 as R, observe as S, poll as T, UnsupportedPackedAbiType as U, createClient as V, createPublicClient as W, http as X, isHex$1 as Y, sha256$5 as Z, createCurve$1 as _, integerRegex$1 as a, localBatchGatewayUrl as a$, sha256$6 as a0, sha384$2 as a1, sha512$4 as a2, hashMessage as a3, slice$3 as a4, toHex$3 as a5, waitForCallsStatus as a6, stringToBytes$1 as a7, trim$2 as a8, decodeFunctionData as a9, k$2 as aA, A$3 as aB, E$3 as aC, i$2 as aD, h$3 as aE, y$2 as aF, formatJsonRpcRequest as aG, r$1 as aH, Ot$2 as aI, o$1 as aJ, f$5 as aK, isJsonRpcRequest as aL, isJsonRpcResponse as aM, formatJsonRpcResult as aN, Nt$4 as aO, Po$3 as aP, Qe$3 as aQ, Qo$3 as aR, safeJsonStringify as aS, safeJsonParse as aT, getBigIntRpcId as aU, formatJsonRpcError as aV, isJsonRpcResult as aW, isJsonRpcError as aX, payloadId as aY, f$2 as aZ, getUrl$1 as a_, hexToString as aa, decodeAbiParameters as ab, erc20Abi as ac, hexToNumber$2 as ad, isAddressEqual as ae, decodeEventLog as af, formatUnits as ag, parseUnits$1 as ah, createTransport as ai, TransactionRejectedRpcError as aj, UserRejectedRequestError as ak, ExecutionRevertedError as al, wait as am, IEvents as an, __vitePreload as ao, bases as ap, getWindowMetadata_1 as aq, cjs$3 as ar, getDocument_1 as as, C$4 as at, getNavigator_1 as au, detect as av, getLocation_1 as aw, sn$2 as ax, bs58 as ay, eventsExports as az, boolToHex$1 as b, localBatchGatewayRequest as b0, call as b1, HttpRequestError as b2, dijkstraExports as b3, concatHex as c, bytesRegex$1 as d, arrayRegex$1 as e, encodeAbiParameters as f, secp256k1 as g, hexToBytes$2 as h, isAddress as i, clsx$1 as j, concat$3 as k, size$7 as l, hashTypedData as m, numberToHex$1 as n, keccak256$3 as o, pad$3 as p, getAction as q, getCode as r, stringToHex$1 as s, readContract as t, parseAbi as u, BaseError$2 as v, prettyPrint as w, formatGwei as x, decodeErrorResult as y, ContractFunctionRevertedError as z };
