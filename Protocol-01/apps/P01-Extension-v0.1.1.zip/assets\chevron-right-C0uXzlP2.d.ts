export const chevronRightSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
