export const walletPlaceholderSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
