export const githubSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
