export const cursorTransparentSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
