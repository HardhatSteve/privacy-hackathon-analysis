export const filtersSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
