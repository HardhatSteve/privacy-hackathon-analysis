export const idSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
