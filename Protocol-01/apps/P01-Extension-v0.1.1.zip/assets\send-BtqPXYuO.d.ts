export const sendSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
