export const facebookSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
