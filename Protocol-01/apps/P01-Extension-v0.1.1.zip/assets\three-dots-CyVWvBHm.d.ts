export const threeDotsSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
