export const telegramSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
