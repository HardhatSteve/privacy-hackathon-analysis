export const reownSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
