export const googleSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
