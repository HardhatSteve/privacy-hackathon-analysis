export const playStoreSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
