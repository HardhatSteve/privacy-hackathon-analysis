export const mailSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
