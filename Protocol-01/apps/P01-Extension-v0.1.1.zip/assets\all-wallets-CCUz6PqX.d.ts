export const allWalletsSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
