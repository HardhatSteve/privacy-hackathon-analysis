export const infoSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
