export const extensionSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
