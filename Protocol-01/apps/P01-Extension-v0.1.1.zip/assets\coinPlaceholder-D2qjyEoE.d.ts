export const coinPlaceholderSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
