export const chevronLeftSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
