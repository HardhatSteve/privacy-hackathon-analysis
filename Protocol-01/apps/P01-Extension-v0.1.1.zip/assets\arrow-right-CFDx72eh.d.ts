export const arrowRightSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
