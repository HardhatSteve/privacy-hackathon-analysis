export const copySvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
