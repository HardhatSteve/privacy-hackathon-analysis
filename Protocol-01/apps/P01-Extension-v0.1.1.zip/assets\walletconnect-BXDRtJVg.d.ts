export const walletConnectBrownSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
export const walletConnectLightBrownSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
export const walletConnectSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
