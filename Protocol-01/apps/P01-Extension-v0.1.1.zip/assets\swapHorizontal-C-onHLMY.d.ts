export const swapHorizontalSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
