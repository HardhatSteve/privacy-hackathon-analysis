export const lightbulbSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
