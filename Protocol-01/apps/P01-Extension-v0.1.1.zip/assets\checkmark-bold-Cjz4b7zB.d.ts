export const checkmarkBoldSvg: {
    _$litType$: any;
    strings: any;
    values: any[];
};
